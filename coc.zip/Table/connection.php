<?php
$host="localhost";
$username="root";
$password="";
$dbname="test";

$con=new mysqli($host,$username,$password,$dbname);
?>