#include <stdio.h>

#define MAX 5  // Number of vertices

// Stack implementation
typedef struct {
    int items[MAX];
    int top;
} Stack;

void initStack(Stack *s) {
    s->top = -1;
}

int isEmpty(Stack *s) {
    return s->top == -1;
}

void push(Stack *s, int value) {
    if (s->top == MAX - 1) {
        return;
    }
    s->items[++s->top] = value;
}

int pop(Stack *s) {
    if (isEmpty(s)) {
        return -1;
    }
    return s->items[s->top--];
}

// DFS function
void DFS(int graph[MAX][MAX], int start) {
    Stack s;
    initStack(&s);

    int visited[MAX] = {0}; // Track visited nodes
    push(&s, start);
    visited[start] = 1;

    printf("DFS Traversal: ");

    while (!isEmpty(&s)) {
        int current = pop(&s);
        printf("%d ", current);

        // Traverse all adjacent vertices
        for (int i = MAX - 1; i >= 0; i--) { // Reverse order for correct DFS sequence
            if (graph[current][i] == 1 && !visited[i]) {
                push(&s, i);
                visited[i] = 1;
            }
        }
    }
    printf("\n");
}

int main() {
    // Adjacency matrix for a predefined graph
    int graph[MAX][MAX] = {
        {0, 1, 1, 0, 0},
        {1, 0, 0, 1, 1},
        {1, 0, 0, 0, 0},
        {0, 1, 0, 0, 0},
        {0, 1, 0, 0, 0}
    };

    int start = 0; // Starting vertex

    DFS(graph, start);

    return 0;
}
