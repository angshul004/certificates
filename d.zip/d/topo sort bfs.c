#include <stdio.h>
#include <stdlib.h>

#define MAX_NODES 100

typedef struct {
    int data[MAX_NODES];
    int front, rear;
} Queue;

void initQueue(Queue *q) {
    q->front = q->rear = 0;
}

void enqueue(Queue *q, int value) {
    q->data[q->rear++] = value;
}

int dequeue(Queue *q) {
    return q->data[q->front++];
}

int isEmpty(Queue *q) {
    return q->front == q->rear;
}

void topologicalSortBFS(int n, int adj[MAX_NODES][MAX_NODES]) {
    int indegree[MAX_NODES] = {0};
    Queue q;
    initQueue(&q);

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (adj[i][j]) {
                indegree[j]++;
            }
        }
    }

    for (int i = 0; i < n; i++) {
        if (indegree[i] == 0) {
            enqueue(&q, i);
        }
    }

    printf("Topological Sort (BFS): ");
    while (!isEmpty(&q)) {
        int u = dequeue(&q);
        printf("%d ", u);

        for (int v = 0; v < n; v++) {
            if (adj[u][v]) {
                indegree[v]--;
                if (indegree[v] == 0) {
                    enqueue(&q, v);
                }
            }
        }
    }
    printf("\n");
}

int main() {
    int n = 6;
    int adj[MAX_NODES][MAX_NODES] = {0};

    adj[5][2] = adj[5][0] = adj[4][0] = adj[4][1] = adj[2][3] = adj[3][1] = 1;

    topologicalSortBFS(n, adj);

    return 0;
}
