import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
from sklearn.datasets import load_boston
from sklearn.model_selection import train_test_split
boston = load_boston()
data=pd.DataFrame(boston.data, columns=boston.feature_names)
data['MEDV']=pd.DataFrame(boston.target)
pd.DataFrame(data.corr().round(2))
x_rm=data['RM'].tolist()
x_ptratio=data['PTRATIO'].tolist()
x=pd.DataFrame(x_rm,x_ptratio)
y=data['MEDV']
x=pd.DataFrame(x)
y=pd.DataFrame(y)
x_train, x_test, y_train, y_test = train_test_split(x,y,test_size=0.2)
print(x_train.shape)
linearRegressionClassifier = LinearRegression()
linearRegressionClassifier.fit(x_train, y_train)
y_pred=linearRegressionClassifier.predict(x_test)
mean_sq_er=np.sqrt(mean_squared_error(y_test, y_pred))
r_2_er=linearRegressionClassifier.score(x_test,y_test)
print(mean_sq_er)
print(r_2_er)