import java.util.Scanner;

public class railfence_encrypt {
    public static String encrypt(String text, int rails) {
        text = text.replaceAll("\\s+", "");
        if (rails <= 1 || text.length() == 0) return text;

        StringBuilder[] rail = new StringBuilder[rails];
        for (int i = 0; i < rails; i++) rail[i] = new StringBuilder();

        int row = 0;
        int dir = 1; // 1 down, -1 up

        for (int i = 0; i < text.length(); i++) {
            rail[row].append(text.charAt(i));
            if (row == 0) dir = 1;
            if (row == rails - 1) dir = -1;
            row += dir;
        }

        StringBuilder cipher = new StringBuilder();
        for (int i = 0; i < rails; i++) cipher.append(rail[i]);
        return cipher.toString();
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter plaintext: ");
        String text = sc.nextLine();

        System.out.print("Enter number of rails: ");
        int rails = sc.nextInt();

        String cipher = encrypt(text, rails);
        System.out.println("Cipher Text: " + cipher);

        sc.close();
    }
}
