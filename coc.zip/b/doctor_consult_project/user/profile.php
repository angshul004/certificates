<?php
require_once "../includes/db_connect.php";
require_once "../includes/session_check.php";
require_once "../includes/functions.php";

check_session("user");
check_and_clear_expired_subscription($conn, $_SESSION['user_id']);


$user_id = $_SESSION['user_id'];
$result = $conn->query("SELECT * FROM users WHERE id = $user_id");
$user = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $conn->query("UPDATE users SET name='$name' WHERE id=$user_id");
    $_SESSION['name'] = $name;
    header("Location: profile.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Profile</title>
    <link rel="stylesheet" href="../assets/css/user.css">
</head>
<body>
    <div class="container">
        <h2>My Profile</h2>
        <form method="POST">
            <label>Name:</label>
            <input type="text" name="name" value="<?= $user['name'] ?>" required><br><br>
            <label>Email:</label>
            <input type="email" value="<?= $user['email'] ?>" readonly><br><br>
            <button type="submit">Update</button>
        </form>
        <br>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>
</body>
</html>
