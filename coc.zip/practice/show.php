<?php
$server="localhost";
$user="root";
$pass="";
$db="test";

$conn= new mysqli($server,$user,$pass,$db);
$sql="SELECT * FROM employee";
$result=$conn->query($sql);
if($result->num_rows>0){
    while($row=$result->fetch_assoc()){
        echo $row['name']."|";
        echo $row['dept']."|";
        echo $row['roll']."|";
    }
}else{
    echo"0 result";
}
$conn->close();
?>