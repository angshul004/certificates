<!DOCTYPE html>
<html>
<head>
    <title>Doctor Consultation System</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container home">
        <header>
            <h1>Doctor Consultation System</h1>
            <p>Your trusted platform for seamless online doctor appointments and consultations.</p>
        </header>

        <div class="role-form">
            <form action="login.php" method="GET">
                <button class="role-btn" name="role" value="patient">
                    <img src="assets/images/cough-6917762_640.jpg" class="role-icon" alt="Patient Icon">
                    <span>Login as Patient</span>
                </button>
                <button class="role-btn" name="role" value="doctor">
                    <img src="assets/images/doctor-6633763_640.png" class="role-icon" alt="Doctor Icon">
                    <span>Login as Doctor</span>
                </button>
            </form>
            <p class="register-link">New user? <a href="register.php">Register here</a></p>
        </div>
    </div>
</body>
</html>
