<?php
session_start();
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

$role = $_GET['role'] ?? 'patient'; // Can be 'patient' or 'doctor'
$message = "";

// If already logged in, redirect based on role
if (isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
    redirectToDashboard($_SESSION['role']);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST["email"]);
    $password = $_POST["password"];

    // ADMIN CHECK FIRST
    if ($email === 'admin@example.com') {
        $stmt = $conn->prepare("SELECT id, name, password FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result && $result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['name'] = $user['name'];
                $_SESSION['role'] = 'admin';
                header("Location: admin/dashboard.php");
                exit;
            }
        }
    }

    // Choose table based on role
    if ($role === "doctor") {
        $stmt = $conn->prepare("SELECT id, name, password FROM doctors WHERE email = ?");
    } else {
        $stmt = $conn->prepare("SELECT id, name, password FROM users WHERE email = ?");
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows === 1) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {
            // Set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['role'] = $role;

            redirectToDashboard($role);
        } else {
            $message = "❌ Invalid password.";
        }
    } else {
        $message = "❌ User not found.";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= ucfirst($role) ?> Login</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container login-box">
        <h2><?= ucfirst($role) ?> Login</h2>

        <?php if ($message): ?>
            <div class="message"><?= $message ?></div>
        <?php endif; ?>

        <form method="POST">
            <input type="email" name="email" placeholder="Enter your email" required>
            <input type="password" name="password" placeholder="Enter your password" required>
            <button type="submit">Login</button>
        </form>
    </div>
</body>
</html>
