#include <stdio.h>
#include <stdlib.h>
int *visited;
int **adj;
int vertex;
int edges;
int *parent;
int cursor;
int cost=0;

void getip(){
    printf("Enter the number of vertices: ");
    scanf("%d", &vertex);
    visited = (int *)malloc(vertex * sizeof(int));
    parent = (int *)malloc(vertex * sizeof(int));
    adj = (int **)malloc(vertex * sizeof(int *));
    for (int i = 0; i < vertex; i++){
        adj[i] = (int *)malloc(vertex * sizeof(int));
        visited[i] = 0;
        parent[i]=-1;
    }

/*Initializing the adjacency matrix with 9999 as during considering min weight we need to find which is min and if we take 0 in adj it will create a problem by considering a non linked path as min*/
    for(int i=0; i<vertex; i++){
        for(int j=0; j<vertex; j++){
            adj[i][j] = 9999;
        }
    }


    printf("Enter number of edges: \n");
    scanf("%d", &edges);
    int i;
    int j;
    printf("Enter vertices pair and their weight:\n");
    for(int k=0; k<edges; k++){
        printf("Enter:\n");
        scanf("%d %d", &i, &j);
        printf("weight: \n");
        scanf("%d", &adj[i][j]);
        adj[j][i] = adj[i][j];
    }
}

void backtrack(){
    int p= parent[cursor];          //storing parent of cursor
    if(p==-1){                      //this means graph is exhausted
        printf("Cost : %d",cost);
        exit(0);
    }
    int flag=0;                     //for checking wheather the parent has its all nodes visited or not.
    for(int j=0; j<vertex; j++){
        if(adj[p][j]!=9999 && visited[j]==0){
            flag=1;
        }
    }
    if(flag==1)
    cursor=p;                       //if not visited then change cursor and no need to backtrack again
    else{
        cursor=p;
        backtrack();                //if visited then change cursor and backtrack again
    }
}

int yet_to_visit(){
    //checking all nodes are visited or not
    for(int i=0; i< vertex;i++){
        if(visited[i]==0)
        return 1;
    }
    return 0;
}

void Prims(){
    printf("Enter source: \n");
    scanf("%d",&cursor);
    visited[cursor]=1;
    
    while(yet_to_visit()==1){
        int min=9999; int min_index=0;
        for(int j=0; j<vertex; j++){
            if(adj[cursor][j]!=9999 && visited[j]==0 && min>adj[cursor][j]){
                min=adj[cursor][j];
                min_index=j;
            }
        }

        if(min==9999)
        backtrack();

        else{
            parent[min_index]=cursor;
            visited[min_index]=1;
            cost+=adj[cursor][min_index];
            cursor=min_index;
        }
    }
}

void main(){
    getip();
    Prims();
    printf("Cost : %d",cost);
}