/*
Assignment � II

Topic : Divide & Conquer












1. Write a program to sort a list of element in an Array using Quick Sort. 
Show the running time complexity w.r.t different input cases(best/average/worst). Also mention the algorithm.





Algorithm:
Choose a pivot element.
Partition the array such that elements less than the pivot are on the left and elements greater than the pivot are on the right.
Recursively apply the above steps to the sub-arrays on the left and right of the pivot.





Code :
#include <stdio.h>

void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

int partition(int arr[], int low, int high) {
    int pivot = arr[high]; // Choosing last element as pivot
    int i = low - 1;
    int j;
    for ( j = low; j < high; j++) {
        if (arr[j] < pivot) {
            i++;
            swap(&arr[i], &arr[j]);
        }
    }
    swap(&arr[i + 1], &arr[high]);
    return (i + 1);
}

void quickSort(int arr[], int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high);

        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

void display(int arr[], int size) {
	int i;
    for ( i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

int main() {
    int arr[] = {10, 7, 8, 9, 1, 5};
    int n = sizeof(arr) / sizeof(arr[0]);

    printf("Original array: ");
    display(arr, n);

    quickSort(arr, 0, n - 1);

    printf("Sorted array: ");
    display(arr, n);

    return 0;
}





Time Complexity Analysis:
Best Case: O(n log n) - Occurs when the pivot divides the array into two equal halves.
Average Case: O(n log n) - Random pivot results in balanced partitions.
Worst Case: O(n�) - Happens when the smallest or largest element is repeatedly chosen as the pivot (e.g., sorted array).





Output:
Original array: 10 7 8 9 1 5 
Sorted array: 1 5 7 8 9 10

















2. Write a program to sort a list of element in an Array using Merge Sort. 
Show the running time complexity w.r.t different input cases(best/average/worst). Also mention the algorithm.





Algorithm:
Divide the array into two halves.
Recursively sort the two halves.
Merge the two sorted halves into one sorted array.





Code:
#include <stdio.h>

void merge(int arr[], int left, int mid, int right) {
    int n1 = mid - left + 1;
    int n2 = right - mid;

    int L[n1], R[n2];
    int m,n;
    for ( m = 0; m < n1; m++)
        L[m] = arr[left + m];
    for ( n = 0; n < n2; n++)
        R[n] = arr[mid + 1 + n];

    int i = 0, j = 0, k = left;

    while (i < n1 && j < n2) {
        if (L[i] <= R[j]) {
            arr[k] = L[i];
            i++;
        } else {
            arr[k] = R[j];
            j++;
        }
        k++;
    }

    while (i < n1) {
        arr[k] = L[i];
        i++;
        k++;
    }

    while (j < n2) {
        arr[k] = R[j];
        j++;
        k++;
    }
}

void mergeSort(int arr[], int left, int right) {
    if (left < right) {
        int mid = left + (right - left) / 2;

        mergeSort(arr, left, mid);
        mergeSort(arr, mid + 1, right);
        merge(arr, left, mid, right);
    }
}

void display(int arr[], int size) {
	int i;
    for ( i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

int main() {
    int arr[] = {12, 11, 13, 5, 6, 7};
    int n = sizeof(arr) / sizeof(arr[0]);

    printf("Original array: ");
    display(arr, n);

    mergeSort(arr, 0, n - 1);

    printf("Sorted array: ");
    display(arr, n);

    return 0;
}





Time Complexity Analysis:
Best Case: O(n log n) - Recursion divides the array evenly.
Average Case: O(n log n) - Same as the best case due to balanced merging.
Worst Case: O(n log n) - Occurs regardless of the input.





Output:
Original array: 12 11 13 5 6 7 
Sorted array: 5 6 7 11 12 13




















3. Write a program to sort a list of element in an Array using Heap Sort. 
Show the running time complexity w.r.t different input cases(best/average/worst). Also mention the algorithm.





Algorithm:
Build a max heap from the input array.
Swap the first element (largest) with the last, reduce the heap size, and heapify.
Repeat until the heap size is 1.





Code:
#include <stdio.h>

void heapify(int arr[], int n, int i) {
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    if (left < n && arr[left] > arr[largest])
        largest = left;

    if (right < n && arr[right] > arr[largest])
        largest = right;

    if (largest != i) {
        int temp = arr[i];
        arr[i] = arr[largest];
        arr[largest] = temp;
        heapify(arr, n, largest);
    }
}

void heapSort(int arr[], int n) {
	int i;
    for ( i = n / 2 - 1; i >= 0; i--)
        heapify(arr, n, i);

    for ( i = n - 1; i > 0; i--) {
        int temp = arr[0];
        arr[0] = arr[i];
        arr[i] = temp;

        heapify(arr, i, 0);
    }
}

void display(int arr[], int size) {
	int i;
    for ( i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

int main() {
    int arr[] = {4, 10, 3, 5, 1};
    int n = sizeof(arr) / sizeof(arr[0]);

    printf("Original array: ");
    display(arr, n);

    heapSort(arr, n);

    printf("Sorted array: ");
    display(arr, n);

    return 0;
}





Time Complexity Analysis:
Best Case: O(n log n) - Balanced heap creation and extraction.
Average Case: O(n log n) - Similar due to heap adjustments.
Worst Case: O(n log n) - Still O(n log n) for skewed data.





Output:
Original array: 4 10 3 5 1 
Sorted array: 1 3 4 5 10

















4. Write a program to find maximum and minimum element present in a list of element using different approach. 
Show the running time complexity w.r.t different input cases(best/average/worst). Finally comment which one is better & why. Also mention the algorithm.





Algorithm:
Divide the array into halves.
Recursively find the maximum and minimum in each half.
Combine the results to find the overall maximum and minimum.





Code:
#include <stdio.h>

typedef struct {
    int max;
    int min;
} Result;

Result findMaxMin(int arr[], int low, int high) {
    Result res, left, right;

    if (low == high) {
        res.max = res.min = arr[low];
        return res;
    }

    if (high == low + 1) {
        if (arr[low] > arr[high]) {
            res.max = arr[low];
            res.min = arr[high];
        } else {
            res.max = arr[high];
            res.min = arr[low];
        }
        return res;
    }

    int mid = (low + high) / 2;
    left = findMaxMin(arr, low, mid);
    right = findMaxMin(arr, mid + 1, high);

    res.max = (left.max > right.max) ? left.max : right.max;
    res.min = (left.min < right.min) ? left.min : right.min;
    return res;
}

int main() {
    int arr[] = {100, 11, 445, 1, 330, 3000};
    int n = sizeof(arr) / sizeof(arr[0]);

    Result res = findMaxMin(arr, 0, n - 1);
    printf("Maximum: %d\n", res.max);
    printf("Minimum: %d\n", res.min);

    return 0;
}





Time Complexity Analysis:
Best Case: O(n) - Linear comparison.
Average Case: O(n) - Same as the best case.
Worst Case: O(n) - Must traverse all elements.

The Divide & Conquer approach is better compared to a simple linear search due to 
its reduced number of comparisons, especially for larger arrays. However, for small datasets, the overhead might make linear search slightly faster.





Output:
Maximum: 3000
Minimum: 1

*/
