<?php
include("header.php");
?>

<a href="insert.html">INSERT COURSE</a><br><br>

<table>
    <tr>
        <th>Course name</th>
        <th>Course Description</th>
        <th>Status</th>
    </tr>
    <?php
        $query="SELECT c_name,c_desc,c_status FROM course";
        $result=mysqli_query($con,$query);
        while($fetch=mysqli_fetch_object($result)){
    ?>
            <tr>
                <td><?php echo $fetch->c_name ?></td>
                <td><?php echo $fetch->c_desc ?></td>
                <td><?php echo $fetch->c_status ?></td>
            </tr>
    <?php
        }
    ?>
</table>

<?php
$con->close();
include("footer.php");
?>