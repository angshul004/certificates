<?php
require_once "../includes/db_connect.php";
require_once "../includes/session_check.php";
require_once "../includes/functions.php";

check_session("doctor");

$doctor_id = $_SESSION['user_id'];
$result = $conn->query("SELECT name, specialization FROM doctors WHERE id = $doctor_id");
$doctor = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Doctor Dashboard</title>
    <link rel="stylesheet" href="../assets/css/doctor.css">
</head>
<body>
    <div class="container">
        <h2>Welcome, Dr. <?= htmlspecialchars($doctor['name']) ?></h2>
        <p>Specialization: <?= htmlspecialchars($doctor['specialization']) ?></p>

        <div class="dashboard-links">
            <a href="appointments.php">📆 View Appointments</a>
            <a href="profile.php">👨‍⚕️Profile</a>
            <a href="../logout.php">🚪Logout</a>
        </div>
    </div>
</body>
</html>

