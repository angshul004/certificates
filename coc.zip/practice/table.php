<?php
$server="localhost";
$user="root";
$pass="";
$db="test";

$conn= new mysqli($server,$user,$pass,$db);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table border="1">
        <th>Name</th>
        <th>Department</th>
        <th>Roll</th>

        <?php
        $sql="SELECT * FROM employee";
        $result=$conn->query($sql);
        while($row=$result->fetch_assoc()){
        ?>
            <tr>
            <td><?php echo $row['name']?></td>
            <td><?php echo $row['dept']?></td>
            <td><?php echo $row['roll']?></td>
            </tr>
        <?php
        }
        ?>
    </table>
    
</body>
</html>