#!/bin/bash

if [ "$#" -ne 3 ]; then
    echo "provide 3 numbers as arguments."
    exit 1
fi

num1=$1
num2=$2
num3=$3

if [ "$num1" -ge "$num2" ] && [ "$num1" -ge "$num3" ]; then
    max=$num1
elif [ "$num2" -ge "$num1" ] && [ "$num2" -ge "$num3" ]; then
    max=$num2
else
    max=$num3
fi

echo "The maximum number is: $max"

