import java.util.Scanner;

public class railfence_decrypt {
    public static String decrypt(String cipher, int rails) {
        cipher = cipher.replaceAll("\\s+", "");
        if (rails <= 1 || cipher.length() == 0) return cipher;

        int len = cipher.length();
        char[][] grid = new char[rails][len];
        for (int i = 0; i < rails; i++) {
            for (int j = 0; j < len; j++) {
                grid[i][j] = '\0';
            }
        }

        // Mark the zigzag positions
        int row = 0, dir = 1;
        for (int col = 0; col < len; col++) {
            grid[row][col] = '*';
            if (row == 0) dir = 1;
            if (row == rails - 1) dir = -1;
            row += dir;
        }

        // Fill marked positions with cipher text
        int idx = 0;
        for (int i = 0; i < rails; i++) {
            for (int j = 0; j < len; j++) {
                if (grid[i][j] == '*' && idx < len) {
                    grid[i][j] = cipher.charAt(idx++);
                }
            }
        }

        // Read the zigzag to reconstruct plaintext
        StringBuilder plain = new StringBuilder();
        row = 0;
        dir = 1;
        for (int col = 0; col < len; col++) {
            plain.append(grid[row][col]);
            if (row == 0) dir = 1;
            if (row == rails - 1) dir = -1;
            row += dir;
        }

        return plain.toString();
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter ciphertext: ");
        String cipher = sc.nextLine();

        System.out.print("Enter number of rails: ");
        int rails = sc.nextInt();

        String plain = decrypt(cipher, rails);
        System.out.println("Plain Text: " + plain);

        sc.close();
    }
}
