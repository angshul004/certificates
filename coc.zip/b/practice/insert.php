<?php
$server="localhost";
$username="root";
$pass="";
$dbname="test";

$conn=new mysqli($server,$username,$pass,$dbname);

if($conn->connect_error){
    die("Connection failed");
}

if($_SERVER["REQUEST_METHOD"]=="POST"){
    $name=$_REQUEST['name'];
    $dept=$_REQUEST['dept'];
    $roll1=$_REQUEST['roll'];
    $roll=intval($roll1);

    $sql="INSERT INTO employee VALUES ('$name','$dept','$roll')";
    $conn->query($sql);

    $conn->close();
}

?>