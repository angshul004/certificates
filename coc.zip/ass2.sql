--    employee table

CREATE TABLE employee (
    emp_id     NUMBER(10),
    f_name     VARCHAR2(50),
    l_name     VARCHAR2(50),
    job_type   VARCHAR2(50),
    salary     NUMBER(10),
    dept       VARCHAR2(50),
    commision  NUMBER(10),
    manager_id NUMBER(10)
);
DESC employee;

ALTER TABLE employee
ADD CONSTRAINT emp_pk PRIMARY KEY (emp_id);

ALTER TABLE employee 
MODIFY f_name VARCHAR2(50) NOT NULL
MODIFY salary NUMBER(10) NOT NULL;

ALTER TABLE employee 
ADD date_of_joining NUMBER(8);

ALTER TABLE employee
ADD CONSTRAINT dept_fk
FOREIGN KEY (dept)
REFERENCES department(d_name);


--    department table

CREATE TABLE department(
    d_name    VARCHAR2(10) PRIMARY KEY,
    d_loc     VARCHAR2(50),
    HOD_id    NUMBER(10)
);
DESC department;

INSERT ALL
INTO department (d_name,d_loc,HOD_id) VALUES ('Sales','Kol',4)
INTO department (d_name,d_loc,HOD_id) VALUES ('Accounts','Delhi',6)
INTO department (d_name,d_loc,HOD_id) VALUES ('Production','Kol',1)
INTO department (d_name,d_loc,HOD_id) VALUES ('Marketing','Kol',2)
INTO department (d_name,d_loc,HOD_id) VALUES ('R & D','Marketing',8)
SELECT * FROM dual;

SELECT * FROM department;



--    location table

CREATE TABLE location(
    loc_id    NUMBER(10),
    city      VARCHAR2(50),
    contact_no    NUMBER(10)
);
DESC location;

ALTER TABLE location
MODIFY city VARCHAR2(55);

ALTER TABLE location
DROP COLUMN contact_no;

ALTER TABLE location
RENAME COLUMN city TO address;

RENAME location TO loc;

DESC loc;

INSERT ALL
INTO loc (loc_id,address) VALUES (1,'Kolkata')
INTO loc (loc_id,address) VALUES (2,'Mumbai')
SELECT * FROM dual;

SELECT * FROM loc;   -- Display the table

TRUNCATE TABLE loc;
DROP TABLE loc;

--










