#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Huffman tree node structure
struct MinHeapNode {
    char data;
    struct MinHeapNode *left, *right;
};

// Function to create a new Huffman node
struct MinHeapNode* newNode(char data) {
    struct MinHeapNode* temp = (struct MinHeapNode*)malloc(sizeof(struct MinHeapNode));
    temp->left = temp->right = NULL;
    temp->data = data;
    return temp;
}

// Function to insert a character and its code into the Huffman tree
void insertCode(struct MinHeapNode* root, char ch, char* code) {
    struct MinHeapNode* current = root;
    for (int i = 0; code[i] != '\0'; i++) {
        if (code[i] == '0') {
            if (!current->left) current->left = newNode('$');
            current = current->left;
        } else {
            if (!current->right) current->right = newNode('$');
            current = current->right;
        }
    }
    current->data = ch;
}

// Function to build Huffman Tree dynamically from input
struct MinHeapNode* buildHuffmanTreeFromInput() {
    int n;
    printf("Enter the number of characters: ");
    scanf("%d", &n);
    
    struct MinHeapNode* root = newNode('$');
    for (int i = 0; i < n; i++) {
        char ch;
        char code[20];
        printf("Enter character and its Huffman code: ");
        scanf(" %c %s", &ch, code);
        insertCode(root, ch, code);
    }
    return root;
}

// Function to decode the encoded string using Huffman Tree
void decodeHuffman(struct MinHeapNode* root, char* encodedString) {
    struct MinHeapNode* current = root;
    printf("Decoded string: ");
    for (int i = 0; encodedString[i] != '\0'; i++) {
        if (encodedString[i] == '0')
            current = current->left;
        else
            current = current->right;
        
        // If a leaf node is reached
        if (!current->left && !current->right) {
            printf("%c", current->data);
            current = root;
        }
    }
    printf("\n");
}

int main() {
    // Build Huffman tree dynamically from input
    struct MinHeapNode* root = buildHuffmanTreeFromInput();
    
    char encodedString[100];
    printf("Enter encoded string: ");
    scanf("%s", encodedString);
    
    decodeHuffman(root, encodedString);
    
    return 0;
}
