<?php
session_start();
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

// Admin authentication check
check_admin_session();

// Count users
$users_count = $conn->query("SELECT COUNT(*) AS total FROM users")->fetch_assoc()['total'];

// Count plans
$plans_count = $conn->query("SELECT COUNT(*) AS total FROM subscriptions")->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<div class="header">
    <h1>Admin Dashboard</h1>
    <p>Welcome, Admin</p>
</div>

<div class="nav">
    <a href="manage_users.php">👥 Manage Users</a>
    <a href="manage_plans.php">📦 Manage Plans</a>
    <a href="../logout.php">🚪 Logout</a>
</div>

<div class="content">
    <div class="welcome">
        <h2>Overview</h2>
        <p>Total Registered Users: <strong><?= $users_count ?></strong></p>
        <p>Total Subscription Plans: <strong><?= $plans_count ?></strong></p>
    </div>
</div>

</body>
</html>
