#include <stdio.h>
int c[100];     //for temporary storage of merged array


void Merge(int A[], int low, int mid, int high){
    int i=low; 
    int j=mid+1;
    int k=low;
    while(i<=mid && j<=high){
        if(A[i]<A[j]){
            c[k]=A[i];
            i++;
            k++;
        }
        if(A[j]<A[i]){
            c[k]=A[j];
            j++;
            k++;
        }
    }
    while(i<=mid){
        c[k]=A[i];
        i++;
        k++;
    }
    while(j<=high){
        c[k]=A[j];
        j++;
        k++;
    }
/*copying back the merged elements to array A[]*/
    for(int i=low; i<=high; i++)
    A[i]=c[i];
}

void Mergesort(int A[], int low, int high){
    if(low<high){
        int mid=(low+high)/2;
        Mergesort(A, low, mid);
        Mergesort(A,mid+1,high);
        Merge(A,low, mid,high);
    }
}

void input(int A[],int size){
    printf("Enter elements :\n");
    for(int i=0; i<size; i++)
    scanf("%d",&A[i]);
}

void display(int A[],int size){
    printf("Array:\n");
    for(int i=0; i<size; i++)
    printf("%d\t",A[i]);
    printf("\n");
}

void main(){
    printf("Enter the size of the array :\n");
    int size;
    scanf("%d",&size);
    int A[size];
    input(A,size);
    display(A,size);
    Mergesort(A,0,size-1);
    display(A,size);
}