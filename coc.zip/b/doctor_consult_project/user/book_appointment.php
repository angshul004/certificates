<?php
require_once "../includes/db_connect.php";
require_once "../includes/session_check.php";
require_once "../includes/functions.php";

check_session("user");
check_and_clear_expired_subscription($conn, $_SESSION['user_id']);


$doctor_id = $_GET['doctor_id'] ?? null;
$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $date = trim($_POST['date']);
    $user_id = $_SESSION['user_id'];

    // Optional: Sanitize input further
    $stmt = $conn->prepare("INSERT INTO appointments (patient_id, doctor_id, appointment_date, status) VALUES (?, ?, ?, 'pending')");
    $stmt->bind_param("iis", $user_id, $doctor_id, $date);

    if ($stmt->execute()) {
        $message = "✅ Appointment requested successfully!";
    } else {
        $message = "❌ Error: " . htmlspecialchars($stmt->error);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Book Appointment</title>
    <link rel="stylesheet" href="../assets/css/user.css">
</head>
<div class="container">
    <body>
        <h2>Book Appointment</h2>
    
        <form method="POST">
            <label for="date">Select Date:</label><br>
            <input type="date" name="date" id="date" required><br><br>
            <button type="submit">Book</button>
        </form>
    
        <?php if ($message): ?>
            <p><?= htmlspecialchars($message) ?></p>
        <?php endif; ?>
    
        <a href="doctors.php">← Back to Doctor List</a>
    </body>
</div>
</html>
