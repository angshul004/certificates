#include <stdio.h>
#include <stdlib.h>
void matrixchainorder(int *p,int n)
{
	int m[n][n];//to store minimum scalar multiplication
	int s[n][n];//to store the split points
	int i,j,k,l,q;
	for (i=1;i<n;i++)
	m[i][i]=0;//we are not interested in self multiplication
	for (l=2;l<n;l++)//l is the chain length
	{
		for (i=1;i<n-l+1;i++)
		{
			j=i+l-1;//ending index
			m[i][j]=INT_MAX;//infinity
			for (k=i;k<=j-1;k++)//we check split points (k) and see if they improve our current minimum value
			{
				q=m[i][k]+m[k+1][j]+p[i-1]*p[k]*p[j];
				if (q<m[i][j])
				{
					m[i][j]=q;
					s[i][j]=k;
				}
			}
		}
	}
	printf("Minimum number of scalar multiplications: %d\n",m[1][n-1]);
	printf("m:\n");
	for (int q=1;q<n;q++)
	{
		for (int r=1;r<n;r++)
		printf("%d ",m[q][r]);
		printf("\n");
	}
	printf("s:\n");
	for (int q=1;q<n;q++)
	{
		for (int r=1;r<n;r++)
		printf("%d ",s[q][r]);
		printf("\n");
	}
}
int main()
{
	int *arr,n;
	printf("Enter size: ");
	scanf("%d",&n);
	arr=(int*)malloc(n*sizeof(int));
	printf("Enter array:\n");
	for (int i=0;i<n;i++)
	scanf("%d",&arr[i]);
	matrixchainorder(arr,n);
}
