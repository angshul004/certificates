<?php
require_once "../includes/db_connect.php";
require_once "../includes/session_check.php";
require_once "../includes/functions.php";

check_session("user");
check_and_clear_expired_subscription($conn, $_SESSION['user_id']);

$user_id = $_SESSION['user_id'];
$result = $conn->query("SELECT a.*, d.name AS doctor_name 
    FROM appointments a 
    JOIN doctors d ON a.doctor_id = d.id 
    WHERE a.patient_id = $user_id 
    ORDER BY a.appointment_date DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Appointments</title>
    <link rel="stylesheet" href="../assets/css/user.css">
</head>
<body>
    <div class="container">
        <h2>My Appointments</h2>
        <ul>
            <?php while ($row = $result->fetch_assoc()): 
                $statusClass = strtolower($row['status']); 
            ?>
                <li>
                    Dr. <?= htmlspecialchars($row['doctor_name']) ?> 
                    on <?= date('d/M/Y', strtotime($row['appointment_date'])) ?> 
                    - Status: <span class="status <?= $statusClass ?>"><?= htmlspecialchars($row['status']) ?></span>
                </li>
            <?php endwhile; ?>
        </ul>
        <a href="dashboard.php" class="back-link">Back to Dashboard</a>
    </div>
</body>
</html>
