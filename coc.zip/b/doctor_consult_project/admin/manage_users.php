<?php
session_start();
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

// Admin authentication check
check_admin_session();

$result = $conn->query("SELECT u.id, u.name, u.email, s.name AS subscription 
    FROM users u 
    LEFT JOIN subscriptions s ON u.subscription_id = s.id
    ORDER BY u.id DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Users</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<div class="header">
    <h1>Manage Users</h1>
</div>

<div class="nav">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="manage_plans.php">📦 Manage Plans</a>
    <a href="../logout.php">🚪 Logout</a>
</div>

<div class="content">
    <h2>User List</h2>
    <table border="1" cellpadding="10" cellspacing="0">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Subscription Plan</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= htmlspecialchars($row['name']) ?></td>
            <td><?= htmlspecialchars($row['email']) ?></td>
            <td><?= $row['subscription'] ?? 'None' ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

</body>
</html>
