<?php
require_once "../includes/db_connect.php";
require_once "../includes/session_check.php";
require_once "../includes/functions.php";

check_session("user");
check_and_clear_expired_subscription($conn, $_SESSION['user_id']);


// Check user subscription status
$user_id = $_SESSION['user_id'];
$userResult = $conn->query("SELECT subscription_id FROM users WHERE id = $user_id");
$user = $userResult->fetch_assoc();
$hasActiveSubscription = !empty($user['subscription_id']); // you can improve this with expiration date later

// Fetch doctors
$result = $conn->query("SELECT id, name, specialization FROM doctors");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Available Doctors</title>
    <link rel="stylesheet" href="../assets/css/user.css">
</head>
<body>
    <div class="container">
        <h2>Available Doctors</h2>
        <ul>
            <?php while ($row = $result->fetch_assoc()): ?>
                <li>
                    Dr. <?= htmlspecialchars($row['name']) ?> 
                    <span class="specialization"><?= htmlspecialchars($row['specialization']) ?></span>
                    - 
                    <?php if ($hasActiveSubscription): ?>
                        <a href="book_appointment.php?doctor_id=<?= $row['id'] ?>">Book</a>
                    <?php else: ?>
                        <a href="subscription.php">Subscribe to Book</a>
                    <?php endif; ?>
                </li>
            <?php endwhile; ?>
        </ul>
        <a href="dashboard.php" class="back-link">Back to Dashboard</a>
    </div>
</body>
</html>
