<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "localhost";
    $username2 = "root";
    $password = "";
    $dbname = "test";

    $name = $_REQUEST['c_name'];
    $desc = $_REQUEST['c_desc'];
    $stat = $_REQUEST['c_status'];

    $conn = new mysqli($servername, $username2, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "INSERT INTO course VALUES ('$name','$desc','$stat')";

    if ($conn->query($sql) === TRUE) {
        echo "New course inserted";
        header("refresh:2; url=index.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
