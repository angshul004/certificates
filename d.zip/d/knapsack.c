//Knapsack problem 
#include<stdio.h>

void bubble_sort(double profit[],double weight[],double ratio[])
{
	int i, j ,n=3;
	for (i = 0 ; i<n-1;i++)
	{
		for(j=0;j<n-i-1;j++)
		if(ratio[j]<ratio[j+1])
		{
			double temp1 = ratio[j];
			ratio[j]=ratio[j+1];
			ratio[j+1]=temp1;
			
			double temp2 = profit[j];
			profit[j]=profit[j+1];
			profit[j+1]=temp2;
			
			double temp3 = weight[j];
			weight[j]=weight[j+1];
			weight[j+1]=temp3;
			
		}
	}
	printf("Profit -> ");
	for (i=0;i<3;i++)
	{
		printf("%.2f ",profit[i]);
	}
	printf("\n");
	
	printf("Weight -> ");
	for (i=0;i<3;i++)
	{
		printf("%.2f ",weight[i]);
	}
	printf("\n");
	
	printf("Ratio  ->  ");
	for (i=0;i<3;i++)
	{
		printf("%.2f  ",ratio[i]);
	}
	printf("\n");
		
}

void knapsack(double profit[],double weight[],double ratio[])
{
	double capacity=0.0,cal_profit=0.0,capacity_limit;
	printf("Enter the maximum capacity :");
	scanf("%lf",&capacity_limit); // L f not 1 f
	int i;
	for(i=0;i<3;i++)
	{
		if(weight[i]+capacity<=capacity_limit)
		{
			capacity+=weight[i];
			cal_profit+=profit[i];
		}
		else
		{
			double remaining_capacity = capacity_limit - capacity ;
			cal_profit+=(profit[i]/weight[i])*remaining_capacity;
			break;
		}
	}
	printf("\n The total profit was = %.2f",cal_profit);
}
int main()
{
	double profit[50]={25,24,15};
	double weight[50]={18,15,10};
	double ratio[50];
	int i;
	for (i=0;i<3;i++)
	{
		ratio[i]=profit[i]/weight[i];
	}
	bubble_sort(profit,weight,ratio);
	knapsack(profit,weight,ratio);
}

