--Create PERSON Table:
CREATE TABLE PERSON (
driver_id VARCHAR(10) PRIMARY KEY,
name VARCHAR(50),
address VARCHAR(100)
);

DESC PARTICIPATED;

-- Create CAR Table:
CREATE TABLE CAR (
regno VARCHAR(20) PRIMARY KEY,
model VARCHAR(50),
year INT
);

-- Create ACCIDENT Table:
CREATE TABLE ACCIDENT (
report_number INT PRIMARY KEY,
accd_date DATE,
location VARCHAR(100)
);

--Create OWNS Table with Foreign Keys:
CREATE TABLE OWNS (
driver_id VARCHAR(10),
regno VARCHAR(20),
PRIMARY KEY (driver_id, regno),
FOREIGN KEY (driver_id) REFERENCES PERSON(driver_id),
FOREIGN KEY (regno) REFERENCES CAR(regno)
);

-- Create PARTICIPATED Table with Foreign Keys:
CREATE TABLE PARTICIPATED (
driver_id VARCHAR(10),
regno VARCHAR(20),
report_number INT,
damage_amount INT,
PRIMARY KEY (driver_id, regno, report_number),
FOREIGN KEY (driver_id) REFERENCES PERSON(driver_id),
FOREIGN KEY (regno) REFERENCES CAR(regno),
FOREIGN KEY (report_number) REFERENCES ACCIDENT(report_number)
);


--Add values
INSERT ALL
  INTO PERSON VALUES ('D1', 'Ravi', 'Kolkata')
  INTO PERSON VALUES ('D2', 'Priya', 'Delhi')
  INTO PERSON VALUES ('D3', 'Amit', 'Mumbai')
  INTO PERSON VALUES ('D4', 'Sara', 'Chennai')
  INTO PERSON VALUES ('D5', 'John', 'Bangalore')
SELECT * FROM DUAL;

INSERT ALL
  INTO CAR VALUES ('WB123', 'Honda City', 2020)
  INTO CAR VALUES ('DL456', 'Hyundai i20', 2019)
  INTO CAR VALUES ('MH789', 'Suzuki Swift', 2021)
  INTO CAR VALUES ('TN321', 'Kia Seltos', 2022)
  INTO CAR VALUES ('KA654', 'Toyota Innova', 2020)
SELECT * FROM DUAL;

INSERT ALL
  INTO ACCIDENT VALUES (101, TO_DATE('2022-01-10','YYYY-MM-DD'), 'Park Street')
  INTO ACCIDENT VALUES (102, TO_DATE('2022-03-15','YYYY-MM-DD'), 'Connaught Place')
  INTO ACCIDENT VALUES (103, TO_DATE('2022-06-20','YYYY-MM-DD'), 'Marine Drive')
  INTO ACCIDENT VALUES (104, TO_DATE('2023-02-05','YYYY-MM-DD'), 'Anna Salai')
  INTO ACCIDENT VALUES (105, TO_DATE('2023-07-18','YYYY-MM-DD'), 'MG Road')
SELECT * FROM DUAL;

INSERT ALL
  INTO OWNS VALUES ('D1', 'WB123')
  INTO OWNS VALUES ('D2', 'DL456')
  INTO OWNS VALUES ('D3', 'MH789')
  INTO OWNS VALUES ('D4', 'TN321')
  INTO OWNS VALUES ('D5', 'KA654')
SELECT * FROM DUAL;

INSERT ALL
  INTO PARTICIPATED VALUES ('D1', 'WB123', 101, 5000)
  INTO PARTICIPATED VALUES ('D2', 'DL456', 102, 3000)
  INTO PARTICIPATED VALUES ('D3', 'MH789', 103, 7000)
  INTO PARTICIPATED VALUES ('D4', 'TN321', 104, 4000)
  INTO PARTICIPATED VALUES ('D5', 'KA654', 105, 6000)
SELECT * FROM DUAL;

SELECT * FROM PARTICIPATED;

INSERT INTO ACCIDENT (report_number, accd_date, location)
VALUES (103, TO_DATE('2024-07-19', 'YYYY-MM-DD'), 'Kolkata');

SELECT COUNT(DISTINCT o.driver_id) AS total_people
FROM OWNS o
JOIN PARTICIPATED p ON o.regno = p.regno
JOIN ACCIDENT a ON p.report_number = a.report_number
WHERE EXTRACT(YEAR FROM a.accd_date) = 2006;

SELECT COUNT(DISTINCT p.report_number) AS accident_count
FROM PARTICIPATED p
JOIN CAR c ON p.regno = c.regno
WHERE c.model = 'Honda City';







