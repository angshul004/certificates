#!/bin/bash
echo "Enter year"
read year

if [ -z "$year" ]; then
    year=$(date +%Y)
fi

if [ $(($year % 100)) -eq 0 ];
then
	if [ $(($year % 400)) -eq 0 ];
	then
	echo "Leap year"
	else
	echo "Not leap year"
	fi
else
	if [ $(($year % 4)) -eq 0 ];
	then
	echo "Leap year"
	else
	echo "Not leap year"
	fi
fi
