import java.util.*;
public class playfairdecrypt {

    static char[][] matrix = new char[5][5];

    // Generate Playfair matrix
    static void generateMatrix(String key) {
        boolean[] used = new boolean[26];
        key = key.toUpperCase().replaceAll("[^A-Z]", "").replace("J", "I");

        int row = 0, col = 0;

        // Fill matrix using key
        for (char ch : key.toCharArray()) {
            if (!used[ch - 'A']) {
                matrix[row][col++] = ch;
                used[ch - 'A'] = true;

                if (col == 5) {
                    row++;
                    col = 0;
                }
            }
        }

        // Fill remaining alphabets
        for (char ch = 'A'; ch <= 'Z'; ch++) {
            if (ch == 'J') continue;

            if (!used[ch - 'A']) {
                matrix[row][col++] = ch;
                used[ch - 'A'] = true;

                if (col == 5) {
                    row++;
                    col = 0;
                }
            }
        }
    }

    // Find position of a character
    static int[] findPosition(char ch) {
        if (ch == 'J') ch = 'I';

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (matrix[i][j] == ch) {
                    return new int[]{i, j};
                }
            }
        }
        return null;
    }

    // Decrypt ciphertext
    static String decrypt(String text) {
        text = text.toUpperCase().replaceAll("[^A-Z]", "").replace("J", "I");

        StringBuilder result = new StringBuilder();

        for (int i = 0; i < text.length(); i += 2) {
            char a = text.charAt(i);
            char b = (i + 1 < text.length()) ? text.charAt(i + 1) : 'X';

            int[] p1 = findPosition(a);
            int[] p2 = findPosition(b);

            // Same row: shift left
            if (p1[0] == p2[0]) {
                result.append(matrix[p1[0]][(p1[1] + 4) % 5]);
                result.append(matrix[p2[0]][(p2[1] + 4) % 5]);
            }
            // Same column: shift up
            else if (p1[1] == p2[1]) {
                result.append(matrix[(p1[0] + 4) % 5][p1[1]]);
                result.append(matrix[(p2[0] + 4) % 5][p2[1]]);
            }
            // Rectangle
            else {
                result.append(matrix[p1[0]][p2[1]]);
                result.append(matrix[p2[0]][p1[1]]);
            }
        }
        return result.toString();
    }

    // Display matrix
    static void displayMatrix() {
        System.out.println("Playfair Matrix:");
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }
    }

    // Main method
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter key: ");
        String key = sc.nextLine();

        System.out.print("Enter ciphertext: ");
        String ciphertext = sc.nextLine();

        generateMatrix(key);
        displayMatrix();

        String plaintext = decrypt(ciphertext);
        System.out.println("Plain Text: " + plaintext);

        sc.close();
    }
}
