<?php
require_once "../includes/db_connect.php";
require_once "../includes/session_check.php";

check_session("user");
check_and_clear_expired_subscription($conn, $_SESSION['user_id']);

$user_id = $_SESSION['user_id'];
$plan_id = $_GET['plan_id'] ?? null;

if (!$plan_id) {
    header("Location: subscription.php");
    exit;
}

// Fetch plan info
$planResult = $conn->query("SELECT * FROM subscriptions WHERE id = $plan_id");
$plan = $planResult->fetch_assoc();

if (!$plan) {
    header("Location: subscription.php");
    exit;
}

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Simulate successful payment

    // Update user's subscription_id and subscription_start
    $stmt = $conn->prepare("UPDATE users SET subscription_id = ?, subscription_start = NOW() WHERE id = ?");
    $stmt->bind_param("ii", $plan_id, $user_id);

    if ($stmt->execute()) {
        $message = "Subscription successful!";
        echo "<script>
                alert('$message');
                window.location.href = 'doctors.php';
              </script>";
        exit;
    } else {
        $message = "Error processing subscription. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Pay for Subscription</title>
    <link rel="stylesheet" href="../assets/css/user.css">
</head>
<body>
    <div class="container">
        <h2>Subscription Payment</h2>
        <p><strong>Plan:</strong> <?= htmlspecialchars($plan['name']) ?></p>
        <p><strong>Price:</strong> ₹<?= htmlspecialchars($plan['price']) ?></p>
        <p><strong>Duration:</strong> <?= htmlspecialchars($plan['duration']) ?> days</p>

        <?php if ($message): ?>
            <p class="message error"><?= htmlspecialchars($message) ?></p>
        <?php endif; ?>

        <form method="POST">
            <button type="submit">Pay Now</button>
        </form>

        <a href="subscription.php" class="back-link">Back to Plans</a>
    </div>
</body>
</html>
