#!/bin/bash
echo "Enter BASIC salary:"
read BASIC

DA=$((BASIC * 52 / 100))
HRA=$((BASIC * 15 / 100))
Gross=$((BASIC + DA + HRA))
PF=$(((BASIC + DA) * 12 / 100))
TakeHome=$((Gross - PF))

echo "BASIC Salary  : $BASIC"
echo "DA : $DA"
echo "HRA : $HRA"
echo "Gross Salary : $Gross"
echo "PF: $PF"
echo "Take Home : $TakeHome"
