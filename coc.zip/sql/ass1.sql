CREATE TABLE employee(
    empno INT,
    ename VARCHAR(50),
    designation VARCHAR(50),
    salary DECIMAL(10,2)
);
DESC employee;

CREATE TABLE new_employee AS 
SELECT * FROM employee;

CREATE TABLE selected_employee AS 
SELECT empno, ename FROM employee;

CREATE TABLE empty_employee AS 
SELECT * FROM employee WHERE 1=0;

ALTER TABLE employee 
MODIFY empno NUMBER(6);

ALTER TABLE employee 
MODIFY empno NUMBER(7) MODIFY ename VARCHAR2(99);

ALTER TABLE employee 
ADD department VARCHAR2(50);

ALTER TABLE employee 
ADD (email VARCHAR2(100), join_date DATE);

ALTER TABLE employee 
DROP COLUMN designation;

ALTER TABLE employee 
DROP (email, join_date);

RENAME employee TO emp;






