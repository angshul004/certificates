<?php
require_once "../includes/db_connect.php";
require_once "../includes/session_check.php";
check_session("user");
check_and_clear_expired_subscription($conn, $_SESSION['user_id']);

?>

<!DOCTYPE html>
<html>
<head>
    <title>User Dashboard</title>
    <link rel="stylesheet" type="text/css" href="../assets/css/user-dash.css">
</head>
<body>

    <div class="header">
        <h1>Welcome, <?= htmlspecialchars($_SESSION["name"]) ?>!</h1>
        <p>User Dashboard - Online Doctor Consultation</p>
    </div>

    <div class="nav">
        <a href="doctors.php">👨‍⚕️ View Doctors</a>
        <a href="subscription.php">💳 Subscription Plans</a>
        <a href="my_appointments.php">📅 My Appointments</a>
        <a href="profile.php">👤 Profile</a>
        <a href="../logout.php">🚪 Logout</a>
    </div>

    <div class="content">
        <div class="welcome">
            <h2>Feeling sick or need medical advice?</h2>
            <p>Find the right doctor, book your appointment, and get recovery — all from here.</p>
        </div>
    </div>


</body>
</html>
