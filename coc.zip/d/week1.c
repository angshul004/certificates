//Assignment1
//Topic : Searching & Sorting

/* 
1. Write a program to search an element in an Array using dynamic memory
allocation. Apply different algorithm separately. Show the running time
complexity w.r.t different input cases(best/average/worst). Finally
comment that which one is better and why.



#include <stdio.h>
#include <stdlib.h>

int c = 0; 

int linear_search(int arr[], int n, int key) {
    for (int i = 0; i < n; i++) {
        c++; 
        if (arr[i] == key) {
            return i; 
        }
    }
    return -1; 
}

int binary_search(int arr[], int n, int key) {
    int lo = 0, hi = n - 1;
    while (lo <= hi) {
    	
        int mid = lo + (hi - lo) / 2;
        if (arr[mid] == key) {
            return mid; 
        }
         c ++;
        if (arr[mid] < key) {
            lo = mid + 1; 
        } else {
            hi = mid - 1; 
        }
    }
    return -1;                        
}

int main() {
    int n, ch, key, position;

    printf("\n1. Linear search\n2. Binary search\nEnter your choice: ");
    scanf("%d", &ch);

    printf("\nEnter the size of the array: ");
    scanf("%d", &n);

    int *arr = (int *)malloc(n * sizeof(int));
    if (!arr) {
        printf("Memory allocation failed!\n");
        return -1;
    }

    printf("Enter sorted array elements:\n");
    for (int i = 0; i < n; i++) {
        printf("%d -> ", i);
        scanf("%d", &arr[i]);
    }

    printf("\nEnter the element to be searched: ");
    scanf("%d", &key);

    switch (ch) {
        case 1:
            position = linear_search(arr, n, key);
            if (position != -1) {
                printf("Found at index %d\n", position);
            } else {
                printf("Element not found\n");
            }
            printf("Executed after %d iterations\n", c);
            break;

        case 2:
            position = binary_search(arr, n, key);
            if (position != -1) {
                printf("Found at index %d\n", position);
            } else {
                printf("Element not found\n");
            }
            printf("Executed after %d iterations\n", c);
            break;

        default:
            printf("Wrong choice\n");
    }

    free(arr);
    return 0;
}



Search Algorithms:-

1.Linear Search:

Scans the array element by element.
Best-case complexity: O(1) (when the target is the first element).
Worst-case complexity: O(n) (when the target is not in the array or is the last element).
Average-case complexity: O(n/2) or O(n).

2.Binary Search:

Requires a sorted array.
Continuously divides the array into halves to locate the target.
Best-case complexity: O(1) (when the target is the middle element).
Worst-case complexity: O(logn).
Average-case complexity: O(logn).

Comparison:
Linear Search: Better for small, unsorted datasets or when the array is rarely accessed.
Binary Search: Much faster for large datasets but requires sorting, which adds overhead.
Once sorted, repeated searches are significantly faster.
Conclusion: Use Binary Search for large, frequently accessed datasets. Use Linear Search for smaller, unsorted datasets or for one-time searches.












2. Write a program to perform insertion sort using dynamic memory allocation.
Show the running time complexity w.r.t different input cases. Finally comment that
whether it is matching with the expected complexity of O(n^2) or not.



#include <stdio.h>
#include <stdlib.h>
int c=0;
void insertion_sort(int *arr, int n) {
    int i, j, key;
    for (i = 0; i < n; i++) {
        key = arr[i];
        j = i - 1;
        while (j >= 0 && arr[j] > key) {
           (c)++; 
            arr[j + 1] = arr[j]; 
            j--;
        }
        (c)++; 
        arr[j + 1] = key;
    }
}

int main() {
    int n, ch, i;
    printf("\nPerforming insertion sort :- ");
    printf("\nEnter the size of the array: ");
    scanf("%d", &n);

    int *arr = (int *)malloc(n * sizeof(int));
    if (!arr) {
        printf("Memory allocation failed!\n");
        return -1;
    }

    printf("Enter array elements:\n");
    for (i = 0; i < n; i++) {
        printf("%d -> ", i);
        scanf("%d", &arr[i]);
    }

    insertion_sort(arr, n); 
    printf("Sorted array:\n");
    for (i = 0; i < n; i++) {
        printf("%d -> ", arr[i]);
    }

    printf("\nNumber of iterations: %d\n", c);

    free(arr);
    return 0;
}



Comment on Observed Complexity:
The observed complexity matches the expected complexity:

Best Case: The runtime is linear O(n), as no shifts are needed.
Average Case: The runtime is quadratic O(n 2 ), as elements require varying levels of shifting.
Worst Case: The runtime is quadratic O(n 2 ), as all elements require the maximum number of shifts.
Conclusion: Insertion Sort performs well for small datasets and nearly sorted arrays but is inefficient 
for large or reverse-sorted datasets due to its O(n 2 ) complexity.













3. Write a program to perform selection sort using dynamic memory allocation.
Show the running time complexity w.r.t different input cases. Finally comment that
whether it is matching with the expected complexity of O(n^2) or not.



#include <stdio.h>
#include <stdlib.h>


int c = 0;

void selection_sort(int *arr, int n) {
    int i, j;
    for (i = 0; i < n - 1; i++) {
        int min = i;
        for (j = i + 1; j < n; j++) {
            c++; 
            if (arr[j] < arr[min]) {
                min = j;
            }
        }
        if (min != i) {
            int temp = arr[i];
            arr[i] = arr[min];
            arr[min] = temp;
        }
    }
}

int main() {
    int n, ch, i;
    printf("\nPerforming selection sort :- ");
    printf("\nEnter the size of the array: ");
    scanf("%d", &n);

    int *arr = (int *)malloc(n * sizeof(int));
    if (!arr) {
        printf("Memory allocation failed!\n");
        return -1;
    }

    printf("Enter array elements:\n");
    for (i = 0; i < n; i++) {
        printf("%d -> ", i);
        scanf("%d", &arr[i]);
    }

    selection_sort(arr, n); 
    printf("Sorted array:\n");
    for (i = 0; i < n; i++) {
        printf("%d -> ", arr[i]);
    }

    printf("\nNumber of comparisons: %d\n", c);

    free(arr);
    return 0;
}





Comment on Observed Complexity
The observed runtime matches the theoretical complexity:
Best Case: O(n 2 ) (still performs n(n-1)/2 comparisons).
Average Case: O(n 2 ) (comparisons are the same; swaps depend on randomness).
Worst Case: O(n 2 ) (maximum number of comparisons and swaps).

Conclusion:

Selection Sort always performs O(n 2 ) operations due to the fixed number of comparisons.
It is not efficient for large datasets but is easy to implement and has a simple structure.















4. Write a program to perform bubble sort using dynamic memory allocation.
Show the running time complexity w.r.t different input cases. Finally comment that
whether it is matching with the expected complexity of O(n^2) or not.



#include <stdio.h>
#include <stdlib.h>
int c=0;
void bubble_sort(int *arr, int n) {
    int i, j;
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - i - 1; j++) {
            (c)++; 
            if (arr[j] > arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

int main() {
    int n, ch, i;
    printf("\nPerforming bubble sort :- ");
    printf("\nEnter the size of the array: ");
    scanf("%d", &n);

    int *arr = (int *)malloc(n * sizeof(int));
    if (!arr) {
        printf("Memory allocation failed!\n");
        return -1;
    }

    printf("Enter array elements:\n");
    for (i = 0; i < n; i++) {
        printf("%d -> ", i);
        scanf("%d", &arr[i]);
    }
    bubble_sort(arr, n); 
    printf("Sorted array:\n");
    for (i = 0; i < n; i++) {
        printf("%d -> ", arr[i]);
    }

    printf("\nNumber of comparisons: %d\n", c);

    free(arr);
    return 0;
}




Comment on Observed Complexity
Best Case: Matches O(n), as no swaps occur and the algorithm exits after one pass.
Average Case: Matches O(n 2 ), as elements are swapped multiple times.
Worst Case: Matches O(n 2 ), requiring the maximum number of swaps.
Conclusion:

Bubble Sort's observed runtime is consistent with its theoretical complexity.
It is easy to implement but inefficient for large datasets.

















5. Critically comment that if in all the above program instead of dynamic
array, if we use static array then whether that would affect the complexity
or not.



Using a static array instead of a dynamic array would not affect the time complexity of the sorting and 
searching algorithms because time complexity is determined by the number of operations performed by the algorithm, 
not the type of memory allocation. 

Time Complexity:

Using static or dynamic arrays does not affect the time complexity of the algorithms because the number of operations remains unchanged.


Practical Utility:

For small, fixed-size problems, static arrays are simpler, faster, and more efficient.
For general-purpose programs where the input size is unknown or variable, dynamic arrays are more flexible and 
practical, avoiding memory limitations and wastage.


Best Choice:

Dynamic arrays are preferred for programs requiring scalability and generality.
Static arrays can be used in resource-constrained or real-time environments where fixed sizes are acceptable.

*/
