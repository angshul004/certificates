import java.util.Scanner;

public class HillCipherDecrypt {

    static int mod(int x, int m) {
        int r = x % m;
        return r < 0 ? r + m : r;
    }

    static int gcd(int a, int b) {
        a = Math.abs(a);
        b = Math.abs(b);
        while (b != 0) {
            int t = a % b;
            a = b;
            b = t;
        }
        return a;
    }

    // Convert character to number (A=0, B=1, ..., Z=25)
    static int charToInt(char c) {
        return c - 'A';
    }

    // Convert number to character
    static char intToChar(int n) {
        return (char) (n + 'A');
    }

    // Extended GCD to find modular inverse
    static int modInverse(int a, int m) {
        a = mod(a, m);
        int t = 0, newT = 1;
        int r = m, newR = a;

        while (newR != 0) {
            int q = r / newR;
            int tempT = t - q * newT;
            t = newT;
            newT = tempT;
            int tempR = r - q * newR;
            r = newR;
            newR = tempR;
        }

        if (r != 1) {
            return -1; // not invertible
        }
        return mod(t, m);
    }

    // Invert matrix modulo 26 using Gauss-Jordan
    static int[][] invertMatrix(int[][] key) {
        int n = key.length;
        int[][] aug = new int[n][2 * n];

        // Build [key | I]
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                aug[i][j] = mod(key[i][j], 26);
            }
            for (int j = 0; j < n; j++) {
                aug[i][n + j] = (i == j) ? 1 : 0;
            }
        }

        for (int col = 0; col < n; col++) {
            // Find or create a pivot with invertible value
            int pivot = -1;
            for (int row = col; row < n; row++) {
                if (gcd(aug[row][col], 26) == 1) {
                    pivot = row;
                    break;
                }
            }

            if (pivot == -1) {
                // Try to create an invertible pivot by row combinations
                boolean made = false;
                for (int row = col; row < n && !made; row++) {
                    for (int row2 = col; row2 < n && !made; row2++) {
                        if (row == row2) continue;
                        for (int k = 1; k < 26; k++) {
                            int candidate = mod(aug[row][col] + k * aug[row2][col], 26);
                            if (gcd(candidate, 26) == 1) {
                                // row = row + k*row2 (mod 26)
                                for (int j = 0; j < 2 * n; j++) {
                                    aug[row][j] = mod(aug[row][j] + k * aug[row2][j], 26);
                                }
                                pivot = row;
                                made = true;
                            }
                        }
                    }
                }
            }

            if (pivot == -1) {
                return null; // not invertible in mod 26
            }

            // Swap rows if needed
            if (pivot != col) {
                int[] tmp = aug[pivot];
                aug[pivot] = aug[col];
                aug[col] = tmp;
            }

            // Normalize pivot row
            int inv = modInverse(aug[col][col], 26);
            for (int j = 0; j < 2 * n; j++) {
                aug[col][j] = mod(aug[col][j] * inv, 26);
            }

            // Eliminate other rows
            for (int row = 0; row < n; row++) {
                if (row == col) continue;
                int factor = aug[row][col];
                if (factor != 0) {
                    for (int j = 0; j < 2 * n; j++) {
                        aug[row][j] = mod(aug[row][j] - factor * aug[col][j], 26);
                    }
                }
            }
        }

        int[][] invKey = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                invKey[i][j] = aug[i][n + j];
            }
        }
        return invKey;
    }

    // Decrypt ciphertext using Hill Cipher
    static String decrypt(String text, int[][] key) {
        text = text.toUpperCase().replaceAll("[^A-Z]", "");

        int n = key.length;
        int rem = text.length() % n;
        if (rem != 0) {
            int pad = n - rem;
            for (int i = 0; i < pad; i++) {
                text += "X";
            }
        }

        int[][] invKey = invertMatrix(key);
        if (invKey == null) {
            return null;
        }

        StringBuilder plainText = new StringBuilder();

        for (int i = 0; i < text.length(); i += n) {
            int[] block = new int[n];
            for (int j = 0; j < n; j++) {
                block[j] = charToInt(text.charAt(i + j));
            }

            for (int r = 0; r < n; r++) {
                int sum = 0;
                for (int c = 0; c < n; c++) {
                    sum += invKey[r][c] * block[c];
                }
                plainText.append(intToChar(mod(sum, 26)));
            }
        }

        return plainText.toString();
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter size of square key matrix (n): ");
        int n = sc.nextInt();
        int[][] key = new int[n][n];

        System.out.println("Enter " + n + "x" + n + " key matrix characters (A-Z):");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                String token = sc.next().toUpperCase();
                while (token.isEmpty() || token.charAt(0) < 'A' || token.charAt(0) > 'Z') {
                    System.out.print("Invalid input. Enter A-Z: ");
                    token = sc.next().toUpperCase();
                }
                key[i][j] = charToInt(token.charAt(0));
            }
        }

        sc.nextLine(); // clear buffer

        System.out.print("Enter ciphertext: ");
        String ciphertext = sc.nextLine();

        String plaintext = decrypt(ciphertext, key);
        if (plaintext == null) {
            System.out.println("Key matrix is not invertible modulo 26.");
        } else {
            System.out.println("Plain Text: " + plaintext);
        }

        sc.close();
    }
}
