#!/bin/bash
echo "Enter lower limit:"
read low
echo "Enter upper limit:"
read high

for ((num=low; num<=high; num++))
do
    if [ $num -le 1 ]
    then
        continue
    fi
    prime=1
    for ((i=2; i*i<=num; i++))
    do
        if [ $((num % i)) -eq 0 ]
        then
            prime=0
            break
        fi
    done
    if [ $prime -eq 1 ]
    then
        echo "$num"
    fi
done

