<?php
session_start();
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

// Admin authentication check
check_admin_session();

// Handle form submission to add a new plan
$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $duration = $_POST['duration'];

    $stmt = $conn->prepare("INSERT INTO subscriptions (name, price, duration) VALUES (?, ?, ?)");
    $stmt->bind_param("sii", $name, $price, $duration);

    if ($stmt->execute()) {
        $message = "Plan added successfully.";
    } else {
        $message = "Error: " . $stmt->error;
    }
}

$plans = $conn->query("SELECT * FROM subscriptions ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Plans</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<div class="header">
    <h1>Manage Subscription Plans</h1>
</div>

<div class="nav">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="manage_users.php">👥 Manage Users</a>
    <a href="../logout.php">🚪 Logout</a>
</div>

<div class="content">
    <h2>Add New Plan</h2>
    <form method="POST">
        <input type="text" name="name" placeholder="Plan Name" required><br>
        <input type="number" name="price" placeholder="Price in ₹" required><br>
        <input type="number" name="duration" placeholder="Duration in Days" required><br>
        <button type="submit">Add Plan</button>
    </form>
    <p><?= $message ?></p>

    <h2>Existing Plans</h2>
    <table border="1" cellpadding="10" cellspacing="0">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Price (₹)</th>
            <th>Duration (Days)</th>
        </tr>
        <?php while ($row = $plans->fetch_assoc()): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= htmlspecialchars($row['name']) ?></td>
            <td><?= $row['price'] ?></td>
            <td><?= $row['duration'] ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

</body>
</html>
