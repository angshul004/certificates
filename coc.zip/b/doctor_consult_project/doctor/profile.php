<?php
require_once "../includes/db_connect.php";
require_once "../includes/session_check.php";
require_once "../includes/functions.php";


check_session("doctor");

$doctor_id = $_SESSION['user_id'];
$result = $conn->query("SELECT * FROM doctors WHERE id = $doctor_id");
$doctor = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Doctor Profile</title>
    <link rel="stylesheet" href="../assets/css/doctor.css">
</head>
<body>
    <div class="container-profile">
        <h2>Profile</h2>
        <p><strong>Name:</strong> <?= $doctor['name'] ?></p>
        <p><strong>Email:</strong> <?= $doctor['email'] ?></p>
        <p><strong>Specialization:</strong> <?= $doctor['specialization'] ?></p>
        <br><a href="dashboard.php" class="back-link">Back to Dashboard</a>
    </div>
</body>
</html>
