<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve user input from form
    $name = $_REQUEST['name'];
    $roll = intval($_REQUEST['roll']);
    $dept = $_REQUEST['dept'];
    $sem = $_REQUEST['sem'];
    $sem_fee = $_REQUEST['sem_fee']; // "Yes" or "No"

    // Database connection setup
    $servername = "localhost";
    $username2 = "root";
    $password = "";
    $dbname = "test";

    // Create connection
    $conn = new mysqli($servername, $username2, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "INSERT INTO student2 (name, roll, dept,sem, sem_fee) VALUES ('$name', $roll, '$dept','$sem', '$sem_fee')";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close connection
    $conn->close();
}
?>
