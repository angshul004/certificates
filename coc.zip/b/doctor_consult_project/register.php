<?php
include 'includes/db_connect.php';
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];

    if ($role === 'doctor') {
        $specialization = $_POST['specialization'];
        $stmt = $conn->prepare("INSERT INTO doctors (name, email, password, specialization, created_at) VALUES (?, ?, ?, ?, NOW())");
        $stmt->bind_param("ssss", $name, $email, $password, $specialization);
    } else {
        $stmt = $conn->prepare("INSERT INTO users (name, email, password, created_at) VALUES (?, ?, ?, NOW())");
        $stmt->bind_param("sss", $name, $email, $password);
    }

    if ($stmt->execute()) {
        $message = "Registration successful. <a href='login.php?role=$role'>Login now</a>";
    } else {
        $message = "Error: " . $stmt->error;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <script>
        function toggleFields(role) {
            document.getElementById("specialization-field").style.display = role === "doctor" ? "block" : "none";
        }
    </script>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container">
        <h2>Register</h2>
        <form method="POST">
            <label><input type="radio" name="role" value="patient" checked onchange="toggleFields(this.value)"> Patient</label>
            <label><input type="radio" name="role" value="doctor" onchange="toggleFields(this.value)"> Doctor</label>
            <br>
            <input type="text" name="name" placeholder="Full Name" required />
            <input type="email" name="email" placeholder="Email" required />
            <input type="password" name="password" placeholder="Password" required />
            <div id="specialization-field" style="display: none;">
                <input type="text" name="specialization" placeholder="Specialization" />
            </div>
            <button type="submit">Register</button>
        </form>
        <p><?= $message ?></p>
    </div>
</body>
</html>