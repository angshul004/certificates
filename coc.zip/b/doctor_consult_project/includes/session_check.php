<?php
// session_check.php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}


function check_session() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    if (!isset($_SESSION['user_id'])) {
        header("Location: ../login.php");
        exit();
    }
}

function check_and_clear_expired_subscription($conn, $user_id) {
    $sql = "SELECT u.subscription_id, u.subscription_start, s.duration
            FROM users u
            JOIN subscriptions s ON u.subscription_id = s.id
            WHERE u.id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $expiryDate = date('Y-m-d', strtotime($row['subscription_start'] . ' + ' . $row['duration'] . ' days'));
        if ($expiryDate < date('Y-m-d')) {
            $conn->query("UPDATE users SET subscription_id = NULL, subscription_start = NULL WHERE id = $user_id");
        }
    }
}

?>
