to open the codes using modelsim:

1. install modelsim and click "jumpstart"
2. click "Open a project"
3. go to folder where all files are saved
4. select the .mpf file (Basic gates.mpf)and open. 
If still says file doesn't exist in project tab, delete all file from project tab (no tick on delete from disk) then right click-> select all the .vhd files of the folder -> add to project.

to compile it:

1. compile > compile all
   or right click a .vhd file from left workspace > compile selected

to view wave:

1. simulate > start simulation > work > select the logic
2. (if wave window doesn't appear) layout > nodesign
3. Right click logic name from left window > add > add all signals to wave
4. right click each input > force > give value 0/1
5. simulate > run > run 100