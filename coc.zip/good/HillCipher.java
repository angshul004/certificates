import java.util.Scanner;

public class HillCipher {

    // Convert character to number (A=0, B=1, ..., Z=25)
    static int charToInt(char c) {
        return c - 'A';
    }

    // Convert number to character
    static char intToChar(int n) {
        return (char) (n + 'A');
    }

    // Encrypt plaintext using Hill Cipher
    static String encrypt(String text, int[][] key) {

        text = text.toUpperCase().replaceAll("[^A-Z]", "");

        int n = key.length;
        // Padding with X to fit block size
        int rem = text.length() % n;
        if (rem != 0) {
            int pad = n - rem;
            for (int i = 0; i < pad; i++) {
                text += "X";
            }
        }

        StringBuilder cipherText = new StringBuilder();

        for (int i = 0; i < text.length(); i += n) {

            int[] block = new int[n];
            for (int j = 0; j < n; j++) {
                block[j] = charToInt(text.charAt(i + j));
            }

            // Matrix multiplication (mod 26)
            for (int r = 0; r < n; r++) {
                int sum = 0;
                for (int c = 0; c < n; c++) {
                    sum += key[r][c] * block[c];
                }
                cipherText.append(intToChar((sum % 26 + 26) % 26));
            }
        }

        return cipherText.toString();
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter size of square key matrix (n): ");
        int n = sc.nextInt();
        int[][] key = new int[n][n];

        System.out.println("Enter " + n + "x" + n + " key matrix characters (A-Z):");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                String token = sc.next().toUpperCase();
                while (token.isEmpty() || token.charAt(0) < 'A' || token.charAt(0) > 'Z') {
                    System.out.print("Invalid input. Enter A-Z: ");
                    token = sc.next().toUpperCase();
                }
                key[i][j] = charToInt(token.charAt(0));
            }
        }

        sc.nextLine(); // clear buffer

        System.out.print("Enter plaintext: ");
        String plaintext = sc.nextLine();

        String cipherText = encrypt(plaintext, key);

        System.out.println("Cipher Text: " + cipherText);

        sc.close();
    }
}
