import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge,LinearRegression,Lasso
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
path="C:/Users/UEM/OneDrive - University Of Engineering & Management/subject/AI/lab/2025/dataset/linear_regression/"
data=pd.read_csv(path+"Boston.csv")
z=pd.DataFrame(data.corr().round(2))
x=data['RM']
y=data['MEDV']
x=pd.DataFrame(x)
print(x.shape)
y=pd.DataFrame(y)
x = np.reshape(x,(len(x), 1))
x_train, x_test, y_train, y_test = train_test_split(x,y,test_size=0.1)
y_test=np.reshape(y_test,(-1,1) )
reg = LinearRegression()
reg = reg.fit(x_train,y_train)
y_pred = reg.predict(x_test)
mean_sq_er=np.sqrt(mean_squared_error(y_test, y_pred))
r2_square = reg.score(y_test, y_pred)
RidgeRegressionClassifier = Lasso()
RidgeRegressionClassifier.fit(x_train, y_train)
y_pred_ridge=RidgeRegressionClassifier.predict(x_test)
mean_sq_er_ridge=np.sqrt(mean_squared_error(y_test, y_pred_ridge))
#r2_square_ridge=RidgeRegressionClassifier.score(y_test, y_pred_ridge)
print("for linear regression: "+ str(mean_sq_er))
print("for ridge regression: "+ str(mean_sq_er_ridge))