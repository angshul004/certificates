import java.util.Scanner;

public class vigenere_decrypt {
    static String normalize(String s) {
        return s.toUpperCase().replaceAll("[^A-Z]", "");
    }

    static String expandKey(String key, int length) {
        StringBuilder out = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            out.append(key.charAt(i % key.length()));
        }
        return out.toString();
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter ciphertext: ");
        String text = normalize(sc.nextLine());

        System.out.print("Enter key: ");
        String key = normalize(sc.nextLine());

        if (key.length() == 0 || text.length() == 0) {
            System.out.println("Text and key must contain A-Z characters.");
            sc.close();
            return;
        }

        key = expandKey(key, text.length());

        StringBuilder decipher = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            int chk = key.charAt(i) - 'A';
            int ch = text.charAt(i) - 'A';
            decipher.append((char) ((ch - chk + 26) % 26 + 'A'));
        }
        System.out.println("Plain: " + decipher);

        sc.close();
    }
}
