<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //Retrieve user input from form
    $name = $_REQUEST['username'];
    $rollt = $_REQUEST['roll'];
    $roll = intval($rollt);

    $servername = "localhost";
    $username2 = "root";
    $password = "";
    $dbname = "test";   //name of the database jekhane table is created

    // connect to the MySQL database with the provided credentials.
    $conn = new mysqli($servername, $username2, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "INSERT INTO student VALUES ('$name', $roll)";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close(); // Close the database connection
}
?>