#include <stdio.h>
#include <stdlib.h>

int *p;
int *w;
double *ratio;
int size;
double profit;

void get_ip(){
    printf("Enter the number of items :\n");
    
    scanf("%d",&size);

    /*initialize*/
    p=(int *)malloc(size*sizeof(int));
    w=(int *)malloc(size*sizeof(int));
    ratio=(double *)malloc(size*sizeof(double));


    printf("Enter weights :\n");
    for(int i=0; i<size; i++)
    scanf("%d",&w[i]);
    printf("Enter profits :\n");
    for(int i=0; i<size; i++)
    scanf("%d",&p[i]);


    /* Calculating ratios :*/
    for(int i=0; i<size; i++)
    ratio[i]=(p[i]*1.0)/w[i];

    /*for(int i=0; i<size; i++)
    printf("%f\t",ratio[i]);                    //for printing ratios
    printf("\n");*/
}


void bubble_sort(){
    for(int i=0; i<size; i++)
        for(int j=0; j<size-i-1; j++)
            if(ratio[j+1]>ratio[j]){
                double temp= ratio[j];
                ratio[j]=ratio[j+1];
                ratio[j+1]=temp;

                int t=p[j];
                p[j]=p[j+1];
                p[j+1]=t;

                t=w[j];
                w[j]=w[j+1];
                w[j+1]=t;
            }
}

void pick_up(){
    printf("Enter weight capacity of the sack :\n");
    int weight;
    scanf("%d",&weight);
    int i=0;
    for(i=0; i<size; i++){
        if(w[i]<=weight){
            profit+=p[i];
            weight-=w[i];
        }
        else
            break;
    }
    if(i<size)
        profit+=(weight * ratio[i]);
}

void main(){
    get_ip();
    bubble_sort();
    pick_up();
    printf("Profit = %f", profit);
}