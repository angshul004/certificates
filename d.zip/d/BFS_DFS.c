//BFS

/*

#include<stdio.h>
#include<stdlib.h>

int arr[50][50];

struct Queue
{
	int front;
	int rear;
	int length;
	int *ptr;
};
void initialize(struct Queue *q)
{
	q->front=-1;
	q->rear = -1;
	
	int l;
	printf("Enter length of the queue : ");
	scanf("%d",&l);
	q->length=l;
	
	q->ptr = (int *)malloc(q->length * sizeof(int));
}
int isEmpty(struct Queue *q)
{
	if( (q->front == -1 && q->rear == -1) || q->front > q->rear )
	{
		return 1;
	}
	return 0;
}
int isFull(struct Queue *q)
{
	if(q->rear == q->length - 1 )
	{
		return 1;
	}
	return 0;
}
void enqueue(struct Queue *q,int item)
{
	if(isFull(q))
	{
		printf("Queue is Full cannot be given more entry.\n");
	}
	q->rear ++;
	q->ptr[q->rear]=item;
	if (q->front == -1) 
	{
        q->front = 0;
    }
}
int dequeue(struct Queue *q)
{
	if(isEmpty(q))
	{
		printf("Queue is empty , nothing to dequeue.");
	}
	int val=q->ptr[q->front];
	q->front++;
	if (q->front > q->rear) 
	{
        q->front = q->rear = -1;
    }
    return val;
}

void adjacency_matrix() {
    int edges, i, j, x, y;
    printf("Enter number of edges: ");
    scanf("%d", &edges);
    
    for (i = 0; i < 7; i++) {
        for (j = 0; j < 7; j++) {
            arr[i][j] = 0;
        }
    }
    
    for (i = 0; i < edges; i++) {
        printf("Enter edge (row col): ");
        scanf("%d %d", &x, &y);
        arr[x][y] = arr[y][x] = 1;
    }
}


int main()
{
	struct Queue q;
	initialize(&q);
	// BFS Implementation 
    int node,j;
    int i = 0;
    int visited[7] = {0,0,0,0,0,0,0};
    
    adjacency_matrix();
     
    printf("\n BFS Traversal : %d", i);
    visited[i] = 1;
    enqueue(&q, i); // Enqueue i for exploration
    while (!isEmpty(&q))
    {
        int node = dequeue(&q);
        for ( j = 0; j < 7; j++)
        {
            if(arr[node][j] ==1 && visited[j] == 0){
                printf("%d", j);
                visited[j] = 1;
                enqueue(&q, j);
            }
        }
    }
    return 0;
}



*/





//DFS

/*

#include <stdio.h>
#include <stdlib.h>

int arr[50][50];

struct Stack {
    int top;
    int size;
    int *ptr;
};

void initialize(struct Stack *s) {
    s->top = -1;
    printf("Enter number of items: ");
    scanf("%d", &s->size);
    s->ptr = (int *)malloc(s->size * sizeof(int));
}

int isEmpty(struct Stack *s) {
    return s->top == -1;
}

void push(struct Stack *s, int item) {
    if (s->top >= s->size - 1) {
        printf("Stack overflow!\n");
        return;
    }
    s->ptr[++s->top] = item;
}

int pop(struct Stack *s) {
    if (isEmpty(s)) {
        printf("Stack underflow!\n");
        return -1;
    }
    return s->ptr[s->top--];
}

void adjacency_matrix() {
    int edges, i, j, x, y;
    printf("Enter number of edges: ");
    scanf("%d", &edges);
    
    for (i = 0; i < 7; i++) {
        for (j = 0; j < 7; j++) {
            arr[i][j] = 0;
        }
    }
    
    for (i = 0; i < edges; i++) {
        printf("Enter edge (row col): ");
        scanf("%d %d", &x, &y);
        arr[x][y] = arr[y][x] = 1;
    }
}

int main() {
    struct Stack s;
    initialize(&s);
    
    int i = 0, j;
    int visited[7] = {0};
    
    adjacency_matrix();
    
    printf("\nDFS Traversal: " );
    visited[i] = 1;
    push(&s, i);
    
    while (!isEmpty(&s)) {
        int node = pop(&s);
        printf("%d ", node);
        
        for (j = 0; j < 7; j++) {
            if (arr[node][j] == 1 && !visited[j]) {
                visited[j] = 1;
                push(&s, j);
            }
        }
    }
    
    return 0;
}

*/



#include <stdio.h>
#include <stdlib.h>

int arr[50][50];

struct Stack {
    int top;
    int size;
    int *ptr;
};

void initialize(struct Stack *s) {
    s->top = -1;
    printf("Enter number of items: ");
    scanf("%d", &s->size);
    s->ptr = (int *)malloc(s->size * sizeof(int));
}

int isEmpty(struct Stack *s) {
    return s->top == -1;
}

void push(struct Stack *s, int item) {
    if (s->top >= s->size - 1) {
        printf("Stack overflow!\n");
        return;
    }
    s->ptr[++s->top] = item;
}

int pop(struct Stack *s) {
    if (isEmpty(s)) {
        printf("Stack underflow!\n");
        return -1;
    }
    return s->ptr[s->top--];
}

void adjacency_matrix() {
    int edges, i, j, x, y;
    printf("Enter number of edges: ");
    scanf("%d", &edges);
    
    for (i = 0; i < 7; i++) {
        for (j = 0; j < 7; j++) {
            arr[i][j] = 0;
        }
    }
    
    for (i = 0; i < edges; i++) {
        printf("Enter edge (row col): ");
        scanf("%d %d", &x, &y);
        arr[x][y] = arr[y][x] = 1;
    }
}

int main() {
    struct Stack s;
    initialize(&s);
    
    int i = 1, j;
    int visited[7] = {0};
    
    adjacency_matrix();
    
    printf("\nDFS Traversal: " );
    visited[i] = 1;
    push(&s, i);
    
    while (!isEmpty(&s)) {
        int node = pop(&s);
        printf("%d ", node);
        
        for (j = 1; j < 8; j++) {
            if (arr[node][j] == 1 && !visited[j]) {
                visited[j] = 1;
                push(&s, j);
            }
        }
    }
    
    return 0;
}
