<?php
require_once "../includes/db_connect.php";
require_once "../includes/session_check.php";
require_once "../includes/functions.php";

check_session("doctor");

$doctor_id = $_SESSION['user_id'];

// Handle confirm/cancel actions
if (isset($_GET['action'], $_GET['id'])) {
    $appointment_id = (int)$_GET['id'];
    $action = $_GET['action'];

    if ($action === 'confirm') {
        $conn->query("UPDATE appointments SET status = 'confirmed' WHERE id = $appointment_id AND doctor_id = $doctor_id");
    } elseif ($action === 'cancel') {
        $conn->query("UPDATE appointments SET status = 'cancelled' WHERE id = $appointment_id AND doctor_id = $doctor_id");
    }

    header("Location: appointments.php");
    exit;
}

// Fetch appointments
$query = "SELECT a.id, a.appointment_date, a.status, u.name AS patient_name
          FROM appointments a
          JOIN users u ON a.patient_id = u.id
          WHERE a.doctor_id = $doctor_id
          ORDER BY a.appointment_date DESC";

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Doctor Appointments</title>
    <link rel="stylesheet" href="../assets/css/doctor.css">
</head>
<body>
    <div class="container-appointments">
        <h2>Your Appointments</h2>
        
        <table class="appointments-table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Patient</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= date('d/M/Y', strtotime($row['appointment_date'])) ?></td>
                        <td><?= htmlspecialchars($row['patient_name']) ?></td>
                        <td>
                            <span class="status <?= strtolower($row['status']) ?>">
                                <?= htmlspecialchars($row['status']) ?>
                            </span>
                        </td>
                        <td>
                            <?php if (strtolower($row['status']) === 'pending'): ?>
                                <div class="action-links">
                                    <a href="?action=confirm&id=<?= $row['id'] ?>" 
                                       class="action-btn confirm-btn">
                                       Confirm
                                    </a>
                                    <a href="?action=cancel&id=<?= $row['id'] ?>" 
                                       class="action-btn cancel-btn"
                                       onclick="return confirm('Cancel this appointment?');">
                                       Cancel
                                    </a>
                                </div>
                            <?php else: ?>
                                <span class="taken-text">Taken</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        
        <a href="dashboard.php" class="back-link">← Back to Dashboard</a>
    </div>
</body>
</html>