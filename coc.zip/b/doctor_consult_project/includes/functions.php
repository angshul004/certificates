<?php
// functions.php

// Sanitize user input
function sanitize_input($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// Redirect helper
function redirect($url) {
    header("Location: $url");
    exit;
}

// Flash message (optional, for alerts)
function set_flash_message($type, $message) {
    $_SESSION['flash'][$type] = $message;
}

function get_flash_message($type) {
    if (isset($_SESSION['flash'][$type])) {
        $msg = $_SESSION['flash'][$type];
        unset($_SESSION['flash'][$type]);
        return $msg;
    }
    return '';
}

function redirectToDashboard($role) {
    if ($role === "doctor") {
        header("Location: doctor/dashboard.php");
    } else {
        header("Location: user/dashboard.php");
    }
    exit;
}

function check_admin_session() {
    if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
        header("Location: ../login.php?role=patient");
        exit;
    }
}
?>
