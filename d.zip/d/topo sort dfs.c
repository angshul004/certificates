#include <stdio.h>
#include <stdlib.h>

#define MAX_NODES 100

typedef struct {
    int data[MAX_NODES];
    int top;
} Stack;

void initStack(Stack *s) {
    s->top = -1;
}

void push(Stack *s, int value) {
    s->data[++s->top] = value;
}

int pop(Stack *s) {
    return s->data[s->top--];
}

int isEmptyStack(Stack *s) {
    return s->top == -1;
}

void dfs(int node, int adj[MAX_NODES][MAX_NODES], int visited[], Stack *s, int n) {
    visited[node] = 1;
    for (int v = 0; v < n; v++) {
        if (adj[node][v] && !visited[v]) {
            dfs(v, adj, visited, s, n);
        }
    }
    push(s, node);
}

void topologicalSortDFS(int n, int adj[MAX_NODES][MAX_NODES]) {
    int visited[MAX_NODES] = {0};
    Stack s;
    initStack(&s);

    for (int i = 0; i < n; i++) {
        if (!visited[i]) {
            dfs(i, adj, visited, &s, n);
        }
    }

    printf("Topological Sort (DFS): ");
    while (!isEmptyStack(&s)) {
        printf("%d ", pop(&s));
    }
    printf("\n");
}

int main() {
    int n = 6;
    int adj[MAX_NODES][MAX_NODES] = {0};

    adj[5][2] = adj[5][0] = adj[4][0] = adj[4][1] = adj[2][3] = adj[3][1] = 1; //adj mat

    topologicalSortDFS(n, adj);

    return 0;
}
