#include <stdio.h>
#include <stdlib.h>

// Function to find the maximum of two numbers
int max(int a, int b) {
    return (a > b) ? a : b;
}

// Function to solve the 0/1 Knapsack problem using dynamic programming
void knapsack(int profit[], int weight[], int n, int capacity_limit) {
    int i, w;
    int dp[n + 1][capacity_limit + 1];

    // Initialize dp array
    for (i = 0; i <= n; i++) {
        for (w = 0; w <= capacity_limit; w++) {
            if (i == 0 || w == 0)
                dp[i][w] = 0; // No profit when no items or no capacity
            else if (weight[i - 1] <= w)
                dp[i][w] = max(dp[i - 1][w], profit[i - 1] + dp[i - 1][w - weight[i - 1]]);
            else
                dp[i][w] = dp[i - 1][w];
        }
    }

    // Output the maximum profit
    printf("Maximum profit: %d\n", dp[n][capacity_limit]);

    // To find selected items
    printf("Selected items: ");
    w = capacity_limit;
    for (i = n; i > 0 && w > 0; i--) {
        if (dp[i][w] != dp[i - 1][w]) {
            printf("Item %d ", i);
            w -= weight[i - 1];
        }
    }
    printf("\n");
}

int main() {
    int n, capacity_limit;

    printf("Enter the number of items: ");
    scanf("%d", &n);

    int profit[n], weight[n];
    printf("Enter the profit and weight of each item:\n");
    for (int i = 0; i < n; i++) {
        printf("Item %d Profit: ", i + 1);
        scanf("%d", &profit[i]);
        printf("Item %d Weight: ", i + 1);
        scanf("%d", &weight[i]);
    }

    printf("Enter the maximum capacity: ");
    scanf("%d", &capacity_limit);

    knapsack(profit, weight, n, capacity_limit);

    return 0;
}
