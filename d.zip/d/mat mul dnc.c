#include <stdio.h>
#define MAX 10

void addMatrix(int A[MAX][MAX], int B[MAX][MAX], int C[MAX][MAX], int size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            C[i][j] = A[i][j] + B[i][j];
        }
    }
}

void subMatrix(int A[MAX][MAX], int B[MAX][MAX], int C[MAX][MAX], int size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            C[i][j] = A[i][j] - B[i][j];
        }
    }
}

void multiplyMatrix(int A[MAX][MAX], int B[MAX][MAX], int C[MAX][MAX], int size) {
    if (size == 1) {
        C[0][0] = A[0][0] * B[0][0];
        return;
    }
    int newSize = size / 2;
    int A11[MAX][MAX], A12[MAX][MAX], A21[MAX][MAX], A22[MAX][MAX];
    int B11[MAX][MAX], B12[MAX][MAX], B21[MAX][MAX], B22[MAX][MAX];
    int C11[MAX][MAX], C12[MAX][MAX], C21[MAX][MAX], C22[MAX][MAX];
    int M1[MAX][MAX], M2[MAX][MAX], M3[MAX][MAX], M4[MAX][MAX], M5[MAX][MAX], M6[MAX][MAX], M7[MAX][MAX];
    int temp1[MAX][MAX], temp2[MAX][MAX];
    
    for (int i = 0; i < newSize; i++) {
        for (int j = 0; j < newSize; j++) {
            A11[i][j] = A[i][j];
            A12[i][j] = A[i][j + newSize];
            A21[i][j] = A[i + newSize][j];
            A22[i][j] = A[i + newSize][j + newSize];

            B11[i][j] = B[i][j];
            B12[i][j] = B[i][j + newSize];
            B21[i][j] = B[i + newSize][j];
            B22[i][j] = B[i + newSize][j + newSize];
        }
    }
    
    addMatrix(A11, A22, temp1, newSize);
    addMatrix(B11, B22, temp2, newSize);
    multiplyMatrix(temp1, temp2, M1, newSize);
    
    addMatrix(A21, A22, temp1, newSize);
    multiplyMatrix(temp1, B11, M2, newSize);
    
    subMatrix(B12, B22, temp1, newSize);
    multiplyMatrix(A11, temp1, M3, newSize);
    
    subMatrix(B21, B11, temp1, newSize);
    multiplyMatrix(A22, temp1, M4, newSize);
    
    addMatrix(A11, A12, temp1, newSize);
    multiplyMatrix(temp1, B22, M5, newSize);
    
    subMatrix(A21, A11, temp1, newSize);
    addMatrix(B11, B12, temp2, newSize);
    multiplyMatrix(temp1, temp2, M6, newSize);
    
    subMatrix(A12, A22, temp1, newSize);
    addMatrix(B21, B22, temp2, newSize);
    multiplyMatrix(temp1, temp2, M7, newSize);
    
    addMatrix(M1, M4, temp1, newSize);
    subMatrix(temp1, M5, temp2, newSize);
    addMatrix(temp2, M7, C11, newSize);
    
    addMatrix(M3, M5, C12, newSize);
    addMatrix(M2, M4, C21, newSize);
    
    addMatrix(M1, M3, temp1, newSize);
    subMatrix(temp1, M2, temp2, newSize);
    addMatrix(temp2, M6, C22, newSize);
    
    for (int i = 0; i < newSize; i++) {
        for (int j = 0; j < newSize; j++) {
            C[i][j] = C11[i][j];
            C[i][j + newSize] = C12[i][j];
            C[i + newSize][j] = C21[i][j];
            C[i + newSize][j + newSize] = C22[i][j];
        }
    }
}

void inputMatrix(int matrix[MAX][MAX], int size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            printf("Enter element [%d][%d]: ", i, j);
            scanf("%d", &matrix[i][j]);
        }
    }
}

void printMatrix(int matrix[MAX][MAX], int size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
}

int main() {
    int A[MAX][MAX], B[MAX][MAX], C[MAX][MAX];
    int size;
    
    printf("Enter size of matrix (must be power of 2): ");
    scanf("%d", &size);
    
    printf("Enter elements of first matrix:\n");
    inputMatrix(A, size);
    printf("Enter elements of second matrix:\n");
    inputMatrix(B, size);
    
    multiplyMatrix(A, B, C, size);
    
    printf("Resultant matrix:\n");
    printMatrix(C, size);
    
    return 0;
}