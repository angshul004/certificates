<?php
require_once "../includes/db_connect.php";
require_once "../includes/session_check.php";
require_once "../includes/functions.php";

check_session("user");
check_and_clear_expired_subscription($conn, $_SESSION['user_id']);


$user_id = $_SESSION['user_id'];

// Fetch user subscription info
$userResult = $conn->query("
    SELECT u.subscription_id, u.subscription_start, s.name AS sub_name, s.duration
    FROM users u
    LEFT JOIN subscriptions s ON u.subscription_id = s.id
    WHERE u.id = $user_id
");
$user = $userResult->fetch_assoc();

$hasActive = false;
if ($user['subscription_id'] && $user['subscription_start']) {
    $expiryDate = date('Y-m-d', strtotime($user['subscription_start'] . ' + ' . $user['duration'] . ' days'));
    if ($expiryDate >= date('Y-m-d')) {
        $hasActive = true;
    }
}

// Get all subscription plans
$plans = $conn->query("SELECT * FROM subscriptions");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Subscription Plans</title>
    <link rel="stylesheet" href="../assets/css/user.css">
</head>
<body>
    <div class="container">
        <h2>Choose a Subscription Plan</h2>

        <?php if ($hasActive): ?>
            <p style="color: green;">
                ✅ You have an active subscription: <strong><?= htmlspecialchars($user['sub_name']) ?></strong><br>
                Expiry Date: <?= date('d M Y', strtotime($user['subscription_start'] . ' + ' . $user['duration'] . ' days')) ?>
            </p>
        <?php else: ?>
            <p style="color: red;">❌ You do not have an active subscription.</p>
        <?php endif; ?>

        <ul>
            <?php while ($row = $plans->fetch_assoc()): ?>
                <li>
                    <?= htmlspecialchars($row['name']) ?> - ₹<?= htmlspecialchars($row['price']) ?> (<?= htmlspecialchars($row['duration']) ?> days)
                    - <a href="pay.php?plan_id=<?= $row['id'] ?>">Subscribe</a>
                </li>
            <?php endwhile; ?>
        </ul>

        <a href="dashboard.php" class="back-link">Back to Dashboard</a>
    </div>
</body>
</html>
